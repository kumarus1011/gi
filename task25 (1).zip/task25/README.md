# todo-management-spring-boot


### URL

http://localhost:8080/data

### Image

![Data Screen](src/main/resources/Capture.PNG)