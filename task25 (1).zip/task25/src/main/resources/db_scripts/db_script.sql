CREATE TABLE `max_values` (
  `id` int NOT NULL AUTO_INCREMENT,
  `appliesto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `freqtype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `limittype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `maxdt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `maxdtqty` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `maxeffdate` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `maxexpdate` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
);

INSERT INTO `max_values` VALUES (1,'appl','daad','dad','2022-07-26','2022-07-26','2022-07-26','2022-07-26');
INSERT INTO `max_values` VALUES (2,'dsd','dhfhg','kjhjghj','2022-07-26','2022-07-26','2022-07-26','2022-07-26');
INSERT INTO `max_values` VALUES (3,'dsd','dhfhg','hghfg','2022-07-26','2022-07-26','2022-07-26','2022-07-26');
INSERT INTO `max_values` VALUES (4,'dsd','dhfhg','bbbb','2022-07-26','2022-07-26','2022-07-26','2022-07-26');
INSERT INTO `max_values` VALUES (5,'dsd','dhfhg','rrrrr','2022-07-26','2022-07-26','2022-07-26','2022-07-26');
