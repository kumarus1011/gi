package com.code.task25.dto;

import com.code.task25.constants.EventSubType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EventDto {

    private int id;

    private EventSubType eventSubType;
}
