package com.code.task25.helper;

import com.code.task25.dto.PolicyRestrict;
import com.code.task25.dto.Withdraw;

import java.util.Arrays;
import java.util.List;

public class Compare {

    public static void main(String[] args) {

        Withdraw withdraw1 = new Withdraw("1", 0001);
        Withdraw withdraw2 = new Withdraw("2", 0002);
        Withdraw withdraw3 = new Withdraw("3", 0003);
        Withdraw withdraw4 = new Withdraw("4", 0004);
        Withdraw withdraw5 = new Withdraw("5", 0005);

        PolicyRestrict policyRestrict1 = new PolicyRestrict("AUG", 0001);
        PolicyRestrict policyRestrict2 = new PolicyRestrict("JUL", 0002);
        PolicyRestrict policyRestrict3 = new PolicyRestrict("SEP", 0003);
        PolicyRestrict policyRestrict4 = new PolicyRestrict("OCT", 0004);
        PolicyRestrict policyRestrict5 = new PolicyRestrict("NOV", 0005);

        List<Withdraw> withdraws = Arrays.asList(withdraw1, withdraw2, withdraw3, withdraw4, withdraw5);

        List<PolicyRestrict> policyRestricts = Arrays.asList(policyRestrict1, policyRestrict2,
                policyRestrict3, policyRestrict4, policyRestrict5);

        withdraws
                .forEach(i -> {
                    if (i.getId().equals("4")) {

                        policyRestricts.forEach(j -> {
                            if (j.getRestrictionType().equals("SEP")) {
                                System.out.println("has value");
                            } else {
                                System.out.println("no value");
                            }
                        });

                    } else {
                        System.out.println("no value");
                    }
                });

    }
}
