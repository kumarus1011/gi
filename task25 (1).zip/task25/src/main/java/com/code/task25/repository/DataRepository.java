package com.code.task25.repository;

import com.code.task25.entity.MaxValues;
import org.springframework.data.jpa.repository.JpaRepository;


public interface DataRepository extends JpaRepository<MaxValues, Long>{

}
