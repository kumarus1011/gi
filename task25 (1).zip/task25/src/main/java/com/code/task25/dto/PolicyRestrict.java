package com.code.task25.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class PolicyRestrict {

    private String restrictionType;

    private int code;
}
