package com.code.task25.controller;

import com.code.task25.service.DataService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DataController {

    private final DataService dataService;

    public DataController(DataService dataService) {
        this.dataService = dataService;
    }

    @GetMapping(value = "/data")
    public String data(ModelMap model) {
        model.put("data", dataService.getAll());
        return "data";
    }

}
