package com.code.task25.service;

import com.code.task25.entity.MaxValues;
import com.code.task25.repository.DataRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DataServiceImpl implements DataService{

    private final DataRepository dataRepository;

    public DataServiceImpl(DataRepository dataRepository) {
        this.dataRepository = dataRepository;
    }

    @Override
    public List<MaxValues> getAll() {
        return dataRepository.findAll();
    }
}
