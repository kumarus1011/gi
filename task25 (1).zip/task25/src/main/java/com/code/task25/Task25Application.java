package com.code.task25;

import com.code.task25.dto.EventDto;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.File;
import java.util.Arrays;
import java.util.List;

@SpringBootApplication
public class Task25Application {

    public static void main(String[] args) {
        SpringApplication.run(Task25Application.class, args);

        test();
    }

    private static void test() {

        try {
            ObjectMapper objectMapper = new ObjectMapper();

            File file = new File("input.json");

            List<EventDto> eventDtos = objectMapper.readValue(file, new TypeReference<>() {
            });
            List<EventDto> eventDtos1 = Arrays.asList(objectMapper.readValue(file, EventDto[].class));
            // EventDto eventDto = objectMapper.readValue(file, EventDto.class);

            System.out.println(eventDtos.size());
            System.out.println(eventDtos1.size());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
