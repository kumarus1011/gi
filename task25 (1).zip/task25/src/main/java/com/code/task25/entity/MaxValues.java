package com.code.task25.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "max_values")
public class MaxValues {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id ;

    @Column(name = "limittype")
    private String limitType ;

    @Column(name = "freqtype")
    private String freqType;

    @Column(name = "appliesto")
    private String appliesTo;

    @Column(name = "maxeffdate")
    private String maxeffDate;

    @Column(name = "maxexpdate")
    private String  maxexpDate;

    @Column(name = "maxdtqty")
    private String maxdtQty;

    @Column(name = "maxdt")
    private String maxDt;

}
