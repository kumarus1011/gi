package com.code.task25.service;

import com.code.task25.entity.MaxValues;

import java.util.List;

public interface DataService {

    List<MaxValues> getAll();
}
