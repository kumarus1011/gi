package com.code.task25.constants;

public enum EventSubType {

    POLICY("POLICY"),
    DCA("DCA"),
    DCA_FEE("DCA_FEE"),
    POLICY_FEE("POLICY_FEE");

    EventSubType(String s1) {

    }
}
