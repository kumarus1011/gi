package com.code.task25.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class Withdraw {

    private String id;

    private int code;

}
