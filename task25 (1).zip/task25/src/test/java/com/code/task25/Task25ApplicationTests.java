package com.code.task25;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Task25ApplicationTests {

	@Test
	void contextLoads() {
	}

}
