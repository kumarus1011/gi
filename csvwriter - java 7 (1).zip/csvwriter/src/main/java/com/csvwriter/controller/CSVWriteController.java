package com.csvwriter.controller;

import com.csvwriter.dto.CSVWriteRS;
import com.csvwriter.service.CSVWriteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

@RestController
@RequestMapping(value = "${api.prefix}/csv-writer")
public class CSVWriteController {

    @Autowired
    private CSVWriteService csvWriteService;

    @RequestMapping(value = "/writeCSV", headers = "Accept=application/json", method = RequestMethod.GET)
    public ResponseEntity<CSVWriteRS> writeCSV() {
        CSVWriteRS csvWriteRS = new CSVWriteRS();

        try {
            this.csvWriteService.writeCSV();
            csvWriteRS.setStatus("SUCCESS");
        } catch (IOException | KeyManagementException | NoSuchAlgorithmException e) {
            e.printStackTrace();
            csvWriteRS.setStatus("FAILED");
        }

        return new ResponseEntity<>(csvWriteRS, HttpStatus.OK);
    }
}
