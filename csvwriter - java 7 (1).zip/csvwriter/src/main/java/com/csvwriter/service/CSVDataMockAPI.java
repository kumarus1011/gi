package com.csvwriter.service;

import com.csvwriter.dto.CSVJsonDataResponseDTO;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

@Component
public class CSVDataMockAPI {

    private final String mockAPIUrl = "https://627727a508221c9684616dc0.mockapi.io/api/csv-writer/getData/CSVData";

//    public CSVJsonDataResponseDTO getResponseData() {
//        //Call mock API URL
//        RestTemplate restTemplate = new RestTemplate();
//
//        CSVJsonDataResponseDTO response;
//        response = restTemplate.getForObject(mockAPIUrl, CSVJsonDataResponseDTO.class);
//
//        return response;
//    }

    public List<CSVJsonDataResponseDTO> responseToCSV() throws NoSuchAlgorithmException, KeyManagementException {
        List<CSVJsonDataResponseDTO> responseDTOS = new ArrayList<>();
        CSVJsonDataResponseDTO responseDTO = null;

        for (int i = 0; i < 10; i++) {
            System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
            RestTemplate restTemplate;

            SSLContext context = SSLContext.getInstance("TLSv1.2");
            context.init(null, null, null);
            SSLContext.setDefault(context);
            CloseableHttpClient httpClient = HttpClientBuilder
                    .create()
                    .setSSLContext(context)
                    .build();
            HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory(httpClient);
            restTemplate = new RestTemplate(factory);

            ResponseEntity resp = restTemplate
                    .exchange(mockAPIUrl, HttpMethod.POST, new HttpEntity<String>(""), CSVJsonDataResponseDTO.class);

            responseDTO = (CSVJsonDataResponseDTO) resp.getBody();
        }

//            Add the responseDto to a List/collection(l1) each time and after tenth time , call
        responseDTOS.add(responseDTO);
        return responseDTOS;
    }
}
