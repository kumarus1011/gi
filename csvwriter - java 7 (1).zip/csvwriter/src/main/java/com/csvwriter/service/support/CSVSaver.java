package com.csvwriter.service.support;

import com.opencsv.CSVWriter;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class CSVSaver {

    public static void saveCSV(List<List<String>> convertedData, CSVWriter csvWriter, List<String[]> csvFeed, String filePath, List<String> headers) {

        for (List<String> data : convertedData) {
            String[] arr = new String[data.size()];
            arr = data.toArray(arr);
            csvFeed.add(arr);
        }

        try {

            for (String[] csvData : csvFeed) {
//                csvWriter.writeNext(csvData);
            }

            csvWriter.close();

            String[] CSV_HEADER = new String[headers.size()];
            CSV_HEADER = headers.toArray(CSV_HEADER);

            Path path = Paths.get(filePath);
            List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
//            lines.add(0, StringUtils.join(CSV_HEADER, '\t'));
            Files.write(path, lines, StandardCharsets.UTF_8);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
