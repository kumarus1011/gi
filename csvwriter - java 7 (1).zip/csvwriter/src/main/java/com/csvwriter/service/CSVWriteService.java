package com.csvwriter.service;

import com.csvwriter.dto.CSVJsonDataDTO;
import com.csvwriter.dto.CSVJsonDataResponseDTO;
import com.csvwriter.service.support.CSVSaver;
import com.opencsv.CSVWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.FileWriter;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class CSVWriteService {

    @Autowired
    private CSVDataMockAPI csvDataMockAPI;

    public void writeCSV() throws IOException, KeyManagementException, NoSuchAlgorithmException {

        //Get API response data
        List<CSVJsonDataResponseDTO> responseDTOList = this.csvDataMockAPI.responseToCSV();

        Date date = new Date();

        //Generate unique file name
        String fileName = this.getUniqueFileName(date);

        //CSV file save to this path in PC
        //C:\Users\Harsha Sandaruwan\Documents\Gayan
        final String filePath = "/Users/Harsha Sandaruwan/Documents/Gayan/" + fileName;

        List<String> headers = new ArrayList<>();
        List<String[]> csvFeed = new ArrayList<>();
        List<List<String>> convertedData = new ArrayList<>();
        CSVWriter csvWriter;

        if (responseDTOList != null && !responseDTOList.isEmpty() && responseDTOList.get(0) != null) {
            for (CSVJsonDataDTO jsonDataDTO : responseDTOList.get(0).getResult()) {
                List<String> splits = new ArrayList<>();
                splits.add(jsonDataDTO.getOwner());
                splits.add(jsonDataDTO.getOwndate());
                splits.add(jsonDataDTO.getDesc());
                splits.add(jsonDataDTO.getComment());
                splits.add(jsonDataDTO.getEntname());
                splits.add(jsonDataDTO.getEntval());
                splits.add(jsonDataDTO.getEntowner());
                splits.add(jsonDataDTO.getStatus());

                convertedData.add(splits);
            }
        }

        FileWriter fileWriter = new FileWriter(filePath);

        csvWriter = new CSVWriter(fileWriter, '\t',
                CSVWriter.NO_QUOTE_CHARACTER,
                CSVWriter.DEFAULT_ESCAPE_CHARACTER,
                CSVWriter.DEFAULT_LINE_END);

        //Save CSV
        CSVSaver.saveCSV(convertedData, csvWriter, csvFeed, filePath, headers);
    }

    private String getUniqueFileName(Date date) {
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        String fileName =
                "Sample_report" + "_" +
                        formatter.format(date)
                                .replace(" ", "_")
                                .replace("/", "_")
                                .replace(":", "_") + ".txt";
        return fileName;
    }
}
