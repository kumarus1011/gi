package com.csvwriter.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CSVJsonDataDTO {

    @JsonProperty("owner")
    private String owner;

    @JsonProperty("owndate")
    private String owndate;

    @JsonProperty("desc")
    private String desc;

    @JsonProperty("comment")
    private String comment;

    @JsonProperty("entname")
    private String entname;

    @JsonProperty("entval")
    private String entval;

    @JsonProperty("entowner")
    private String entowner;

    @JsonProperty("status")
    private String status;

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getOwndate() {
        return owndate;
    }

    public void setOwndate(String owndate) {
        this.owndate = owndate;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getEntname() {
        return entname;
    }

    public void setEntname(String entname) {
        this.entname = entname;
    }

    public String getEntval() {
        return entval;
    }

    public void setEntval(String entval) {
        this.entval = entval;
    }

    public String getEntowner() {
        return entowner;
    }

    public void setEntowner(String entowner) {
        this.entowner = entowner;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
