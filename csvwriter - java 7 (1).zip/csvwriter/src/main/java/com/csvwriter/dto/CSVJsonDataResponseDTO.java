package com.csvwriter.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CSVJsonDataResponseDTO {

    @JsonProperty("requestId")
    private String requestId;

    @JsonProperty("anyKey")
    private String anyKey;

    @JsonProperty("run")
    private String run;

    @JsonProperty("reco")
    private String reco;

    @JsonProperty("result")
    private List<CSVJsonDataDTO> result;

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getAnyKey() {
        return anyKey;
    }

    public void setAnyKey(String anyKey) {
        this.anyKey = anyKey;
    }

    public String getRun() {
        return run;
    }

    public void setRun(String run) {
        this.run = run;
    }

    public String getReco() {
        return reco;
    }

    public void setReco(String reco) {
        this.reco = reco;
    }

    public List<CSVJsonDataDTO> getResult() {
        if (result == null) {
            result = new ArrayList<>();
        }
        return result;
    }

    public void setResult(List<CSVJsonDataDTO> result) {
        this.result = result;
    }
}
