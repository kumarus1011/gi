package com.csvwriter;

//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CsvwriterApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
