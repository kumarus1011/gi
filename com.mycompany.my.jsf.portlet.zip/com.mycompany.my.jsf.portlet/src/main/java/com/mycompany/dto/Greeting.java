package com.mycompany.dto;

public class Greeting {

	@Override
	public String toString() {
		return "Greetings from CDI";
	}
}