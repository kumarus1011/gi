package com.kumarkum.project.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.Valid;

import com.kumarkum.project.model.MaxValues;
import com.kumarkum.project.service.MaxValueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

@Controller
public class MaxValueController {

	@Autowired
	private MaxValueService maxValueService;

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
	}

	@GetMapping(value = "/list-max-value")
	public String showMaxValue(ModelMap model) {
		model.put("maxValues", maxValueService.getAll());
		return "list-max-value";
	}

	@GetMapping(value = "/add-max-value")
	public String showAddMaxValuePage(ModelMap model) {
		model.addAttribute("maxValues", new MaxValues());
		return "max-value";
	}

	@GetMapping(value = "/delete-max-value")
	public String deleteMaxValue(@RequestParam long id) {
		maxValueService.deletePool(id);
		return "redirect:/list-max-value";
	}

	@GetMapping(value = "/update-max-value")
	public String showUpdateMaxValuePage(@RequestParam long id, ModelMap model) {
		MaxValues maxValues = maxValueService.getPoolById(id).get();
		model.put("maxValues", maxValues);
		return  "max-value";
	}

	@PostMapping(value = "/update-max-value")
	public String updateMaxValuePage(@RequestParam long id, @Valid MaxValues maxValues, ModelMap model) {
		maxValues.setId(id);
		maxValueService.savePool(maxValues);
		model.put("maxValues", maxValues);
		return "redirect:/list-max-value";
	}

	@PostMapping(value = "/add-max-value")
	public String addMaxValue(ModelMap model, @Valid MaxValues maxValues, BindingResult result) {

		if (result.hasErrors()) {
			return "max-value";
		}
		maxValueService.savePool(maxValues);
		return "redirect:/list-max-value";
	}
}
