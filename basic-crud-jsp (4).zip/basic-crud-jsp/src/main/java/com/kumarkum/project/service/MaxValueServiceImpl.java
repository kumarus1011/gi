package com.kumarkum.project.service;

import java.util.List;
import java.util.Optional;

import com.kumarkum.project.model.MaxValues;
import com.kumarkum.project.repository.MaxValuesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MaxValueServiceImpl implements MaxValueService {

	@Autowired
	private MaxValuesRepository maxValuesRepository;

	@Override
	public List<MaxValues> getAll() {
		return maxValuesRepository.findAll();
	}

	@Override
	public Optional<MaxValues> getPoolById(long id) {
		return maxValuesRepository.findById(id);
	}

	@Override
	public void deletePool(long id) {
		Optional<MaxValues> todo = maxValuesRepository.findById(id);
		if (todo.isPresent()) {
			maxValuesRepository.delete(todo.get());
		}
	}

	@Override
	public void savePool(MaxValues maxValues) {
		maxValuesRepository.save(maxValues);
	}
}