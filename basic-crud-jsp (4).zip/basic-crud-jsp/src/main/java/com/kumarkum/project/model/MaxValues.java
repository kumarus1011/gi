package com.kumarkum.project.model;



import javax.persistence.*;

@Entity
@Table(name = "max_values")
public class MaxValues {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	private String limitType;

	private String freqType ;

	private String appliesTo;

	private String maxEffDate ;

	private String maxExpDate ;

	private String maxDtQty;

	private String maxDt ;

	public MaxValues() {
		super();
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getLimitType() {
		return limitType;
	}

	public void setLimitType(String limitType) {
		this.limitType = limitType;
	}

	public String getFreqType() {
		return freqType;
	}

	public void setFreqType(String freqType) {
		this.freqType = freqType;
	}

	public String getAppliesTo() {
		return appliesTo;
	}

	public void setAppliesTo(String appliesTo) {
		this.appliesTo = appliesTo;
	}

	public String getMaxEffDate() {
		return maxEffDate;
	}

	public void setMaxEffDate(String maxEffDate) {
		this.maxEffDate = maxEffDate;
	}

	public String getMaxExpDate() {
		return maxExpDate;
	}

	public void setMaxExpDate(String maxExpDate) {
		this.maxExpDate = maxExpDate;
	}

	public String getMaxDtQty() {
		return maxDtQty;
	}

	public void setMaxDtQty(String maxDtQty) {
		this.maxDtQty = maxDtQty;
	}

	public String getMaxDt() {
		return maxDt;
	}

	public void setMaxDt(String maxDt) {
		this.maxDt = maxDt;
	}
}