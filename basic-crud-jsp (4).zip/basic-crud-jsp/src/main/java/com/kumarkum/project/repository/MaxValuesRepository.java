package com.kumarkum.project.repository;

import com.kumarkum.project.model.MaxValues;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MaxValuesRepository extends JpaRepository<MaxValues, Long>{
}
