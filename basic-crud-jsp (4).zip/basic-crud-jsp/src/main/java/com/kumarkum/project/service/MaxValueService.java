package com.kumarkum.project.service;

import java.util.List;
import java.util.Optional;

import com.kumarkum.project.model.MaxValues;

public interface MaxValueService {

	List<MaxValues> getAll();

	Optional<MaxValues> getPoolById(long id);

	void deletePool(long id);
	
	void savePool(MaxValues maxValues);
}