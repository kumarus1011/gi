package com.code.task24.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResultsDto {

    private String owner;
    private String owndate;
    private String desc;
    private String comment;
    private String entname;
    private String entval;
    private String entowner;
    private String status;

}
