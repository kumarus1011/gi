package com.code.task24.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RequestDto {

    private String id;
    private String max;
    private String offset;
    private String user;
}
