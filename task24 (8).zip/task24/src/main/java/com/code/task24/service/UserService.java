package com.code.task24.service;

import com.code.task24.dto.ResponseDto;
import com.code.task24.dto.ResultsDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.opencsv.CSVWriter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class UserService {

    @Value("${test.url}")
    private String url;

    public ResponseEntity<ResponseDto> saveOld() {

        try {
            String requestDto = "{\n" +
                    "   \"id\":\"65\",\n" +
                    "   \"max\":\"200\",\n" +
                    "   \"offset\":\"0\",\n" +
                    "   \"user\":\"admin\"\n" +
                    "}";

            log.info(requestDto);

            List<String[]> dataLines = new ArrayList<>();
            dataLines.add(new String[]
                    {"owner", "owndate", "desc", "comment", "entname", "entval", "entowner", "status"});

            for (int i = 0; i < 10; i++) {

                URL obj = new URL(url);
                HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
                postConnection.setRequestMethod("POST");
                postConnection.setRequestProperty("Content-Type", "application/json");
                postConnection.setDoOutput(true);
                int responseCode = postConnection.getResponseCode();

                log.info("POST Response Code {} :", responseCode);
                log.info("POST Response Message {} :", postConnection.getResponseMessage());

                if (responseCode == HttpURLConnection.HTTP_CREATED) { //success
                    BufferedReader in = new BufferedReader(new InputStreamReader(
                            postConnection.getInputStream()));
                    String inputLine;
                    StringBuffer response = new StringBuffer();

                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }

                    // print result
                    log.info(String.valueOf(response));

                    ResponseDto responseDto= new ObjectMapper().readValue(response.toString(), ResponseDto.class);

                    if (responseDto != null) {
                        for (ResultsDto s : responseDto.getResult()) {
                            rowMapper(s, dataLines);
                        }
                    }
                    in.close();
                } else {
                    log.info("POST NOT WORKED");
                }
                responseToCSV2(dataLines);
                responseToTSV2(dataLines);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private void rowMapper(ResultsDto resultsDto, List<String[]> dataLines) {
        dataLines.add(new String[]
                {resultsDto.getOwner(), resultsDto.getOwndate(), resultsDto.getDesc(),
                        resultsDto.getComment(), resultsDto.getEntname(), resultsDto.getEntval(),
                        resultsDto.getEntowner(), resultsDto.getStatus()});

    }

    public void responseToCSV2(List<String[]> dataLines) throws IOException {

        try (CSVWriter writer = new CSVWriter(new FileWriter("src/main/resources/test1.csv"))) {
            writer.writeAll(dataLines);
        }
    }

    public void responseToTSV2(List<String[]> dataLines) throws IOException {

       /* Deprecated

        List<String[]> dataLinesTab = new ArrayList<>();

        for (String[] dataLine : dataLines) {
            dataLinesTab.add(new String[]{Arrays.toString(dataLine)});
        }
        */

        try (CSVWriter writer = new CSVWriter(new FileWriter("src/main/resources/test2.tsv"),
                '\t',
                CSVWriter.NO_QUOTE_CHARACTER,
                CSVWriter.DEFAULT_ESCAPE_CHARACTER,
                CSVWriter.DEFAULT_LINE_END)) {
            writer.writeAll(dataLines);
        }
    }
}
