package com.code.task24.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class ResponseDto {

    private String requestId;
    private String anyKey;
    private String run;
    private String reco;
    private List<ResultsDto> result;
}
