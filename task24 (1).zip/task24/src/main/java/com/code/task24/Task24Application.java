package com.code.task24;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Task24Application {

	public static void main(String[] args) {
		System.setProperty("javax.net.debug", "all");
		System.setProperty("https.protocols", "TLSv1.2");
//		System.setProperty("https.protocols", "TLSv1.2");
		SpringApplication.run(Task24Application.class, args);
	}

}
