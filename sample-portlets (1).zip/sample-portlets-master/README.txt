Sample Java portlets (JSR-168/286)

Portlets kept in this repository are mostly copies from other places on the net, 
modified to be deployed directly to a Sun GlassFish Web Space Server 10.0/Liferay 5.2.1
(often the samples you find on the Internet need some tuning for deployment to a specific portal server).

EventingMap
  
  Portlet 2.0 Eventing Sample, available under COMMON DEVELOPMENT AND DISTRIBUTION LICENSE (CDDL) Version 1.0 (http://www.sun.com/cddl/)
  from http://java.sun.com/developer/technicalArticles/J2EE/sdk_portletcontainer2/#Sample_Application:Events
  
  This version has been modified for deployment to the Liferay portal container.