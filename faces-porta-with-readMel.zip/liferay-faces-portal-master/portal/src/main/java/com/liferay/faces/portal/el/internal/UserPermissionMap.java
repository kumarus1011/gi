/**
 * Copyright (c) 2000-2022 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */
package com.liferay.faces.portal.el.internal;

import java.util.HashMap;

import javax.faces.context.FacesContext;

import com.liferay.faces.portal.context.LiferayPortletHelperUtil;


/**
 * The <code>UserPermissionMap</code> is an API that provides a way to lookup user permissions with a simply <code>
 * java.util.Map</code> interface.
 *
 * @author  Neil Griffin
 */
public class UserPermissionMap extends HashMap<String, Boolean> {

	// serialVersionUID
	private static final long serialVersionUID = 3480405658664457419L;

	@Override
	public Boolean get(Object actionIdAsObject) {

		Boolean value = super.get(actionIdAsObject);

		if (value == null) {

			value = Boolean.FALSE;

			String actionId = (String) actionIdAsObject;

			if (actionId != null) {
				FacesContext facesContext = FacesContext.getCurrentInstance();
				value = LiferayPortletHelperUtil.userHasPortletPermission(facesContext, actionId);
			}

			put(actionId, value);
		}

		return value;
	}

}
