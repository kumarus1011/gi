#!/bin/sh
mvn generate-sources -P generate-components
