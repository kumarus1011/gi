#!/bin/sh
mvn verify -P selenium-portal-showcase
