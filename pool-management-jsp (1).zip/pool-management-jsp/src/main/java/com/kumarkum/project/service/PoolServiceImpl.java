package com.kumarkum.project.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.kumarkum.project.model.Pool;
import com.kumarkum.project.repository.PoolRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PoolServiceImpl implements PoolService {

	@Autowired
	private PoolRepository poolRepository;

	@Override
	public List<Pool> getAll() {
		return poolRepository.findAll();
	}

	@Override
	public Optional<Pool> getPoolById(long id) {
		return poolRepository.findById(id);
	}

	@Override
	public void deletePool(long id) {
		Optional<Pool> todo = poolRepository.findById(id);
		if (todo.isPresent()) {
			poolRepository.delete(todo.get());
		}
	}

	@Override
	public void savePool(Pool pool) {
		pool.setCreateTime(new Date());
		poolRepository.save(pool);
	}
}