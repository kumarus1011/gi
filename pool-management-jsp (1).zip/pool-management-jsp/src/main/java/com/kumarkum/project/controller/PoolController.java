package com.kumarkum.project.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.Valid;

import com.kumarkum.project.model.Pool;
import com.kumarkum.project.service.PoolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

@Controller
public class PoolController {

	@Autowired
	private PoolService poolService;

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
	}

	@GetMapping(value = "/list-pool")
	public String showPool(ModelMap model) {
		model.put("pools", poolService.getAll());
		return "list-pool";
	}

	@GetMapping(value = "/add-pool")
	public String showAddPoolPage(ModelMap model) {
		model.addAttribute("pool", new Pool());
		return "pool";
	}

	@GetMapping(value = "/delete-pool")
	public String deletePool(@RequestParam long id) {
		poolService.deletePool(id);
		return "redirect:/list-pool";
	}

	@GetMapping(value = "/update-pool")
	public String showUpdatePoolPage(@RequestParam long id, ModelMap model) {
		Pool pool = poolService.getPoolById(id).get();
		model.put("pool", pool);
		return  "pool";
	}

	@PostMapping(value = "/update-pool")
	public String updatePoolPage(@RequestParam long id, @Valid Pool pool, ModelMap model) {
		pool.setId(id);
		poolService.savePool(pool);
		model.put("pool", pool);
		return "redirect:/list-pool";
	}

	@PostMapping(value = "/add-pool")
	public String addPool(ModelMap model, @Valid Pool pool, BindingResult result) {

		if (result.hasErrors()) {
			return "pool";
		}
		poolService.savePool(pool);
		return "redirect:/list-pool";
	}
}
