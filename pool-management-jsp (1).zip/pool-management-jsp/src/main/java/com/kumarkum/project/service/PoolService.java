package com.kumarkum.project.service;

import java.util.List;
import java.util.Optional;

import com.kumarkum.project.model.Pool;

public interface PoolService {

	List<Pool> getAll();

	Optional<Pool> getPoolById(long id);

	void deletePool(long id);
	
	void savePool(Pool pool);
}