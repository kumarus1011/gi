package com.kumarkum.project.model;



import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "pool")
public class Pool {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	private String poolId;

	private Date issueDate;

	private String poolClass;

	private String poolStructure;

	private String poolSuffix;

	private String loan;

	private String status;

	private Boolean busRules;

	private Date createTime;

	public Pool() {
		super();
	}

	public Pool(String poolId, Date issueDate, String poolClass, String poolStructure, String poolSuffix, String loan,
				String status, Boolean busRules, Date createTime) {
		this.poolId = poolId;
		this.issueDate = issueDate;
		this.poolClass = poolClass;
		this.poolStructure = poolStructure;
		this.poolSuffix = poolSuffix;
		this.loan = loan;
		this.status = status;
		this.busRules = busRules;
		this.createTime = createTime;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getPoolId() {
		return poolId;
	}

	public void setPoolId(String poolId) {
		this.poolId = poolId;
	}

	public Date getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}

	public String getPoolClass() {
		return poolClass;
	}

	public void setPoolClass(String poolClass) {
		this.poolClass = poolClass;
	}

	public String getPoolStructure() {
		return poolStructure;
	}

	public void setPoolStructure(String poolStructure) {
		this.poolStructure = poolStructure;
	}

	public String getPoolSuffix() {
		return poolSuffix;
	}

	public void setPoolSuffix(String poolSuffix) {
		this.poolSuffix = poolSuffix;
	}

	public String getLoan() {
		return loan;
	}

	public void setLoan(Boolean loan) {
		loan = loan;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Boolean getBusRules() {
		return busRules;
	}

	public void setBusRules(Boolean busRules) {
		this.busRules = busRules;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
}