liferay-demo
============

Sample portlet using JSF 2 with Prime Faces
