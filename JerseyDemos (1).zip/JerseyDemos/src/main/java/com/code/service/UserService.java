package com.code.service;

import com.code.dto.ResponseDto;
import com.code.dto.ResultsDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.opencsv.CSVWriter;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.logging.Logger;

public class UserService {

    Logger log = Logger.getLogger(UserService.class.getName());

    public static final String CSV = ".csv";

    private String url = "http://webhook.site/0f3a3b08-1744-4809-9f51-3a2385830945";

    private String path1 = "files/test1.csv";

    private String path2 = "files/test2.csv";

    public String saveOld() {

        try {
            String requestDto = "{\n" +
                    "   \"id\":\"65\",\n" +
                    "   \"max\":\"200\",\n" +
                    "   \"offset\":\"0\",\n" +
                    "   \"user\":\"admin\"\n" +
                    "}";

            log.info("REQUEST DTO IS {}" + requestDto);

            List<String[]> dataLines = new ArrayList<>();
            dataLines.add(new String[]
                    {"owner", "owndate", "desc", "comment", "entname", "entval", "entowner", "status", "id", "created_Date", "efective_Date"});

            for (int i = 0; i < 10; i++) {

                URL obj = new URL(url);
                HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
                postConnection.setRequestMethod("POST");
                postConnection.setRequestProperty("Content-Type", "application/json");
                postConnection.setDoOutput(true);
                int responseCode = postConnection.getResponseCode();

                log.info("POST Response Code {} :" + responseCode);
                log.info("POST Response Message {} :" + postConnection.getResponseMessage());

                if (responseCode == HttpURLConnection.HTTP_CREATED) { //success
                    BufferedReader in = new BufferedReader(new InputStreamReader(
                            postConnection.getInputStream()));
                    String inputLine;
                    StringBuffer response = new StringBuffer();

                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }

                    // print result
                    log.info("RESPONSE IS {}" + String.valueOf(response));

                    ResponseDto responseDto = new ObjectMapper().readValue(response.toString(), ResponseDto.class);

                    if (responseDto != null) {
                        for (ResultsDto s : responseDto.getResult()) {
                            rowMapper(s, dataLines);
                        }
                    }
                    in.close();
                } else {
                    log.info("POST NOT WORKED");
                }
                responseToCSV2(dataLines);
                responseToTSV2(dataLines);

            }
        } catch (Exception e) {
            log.info("ERROR WHILE PROCESSING {}" + e.getLocalizedMessage());
            e.printStackTrace();
        }
        return null;
    }

    private void rowMapper(ResultsDto resultsDto, List<String[]> dataLines) {

        log.info("ADDING DATA LINES");

        dataLines.add(new String[]
                {
                        removeBlank(resultsDto.getOwner()),
                        removeBlank(resultsDto.getOwndate()),
                        removeBlank(resultsDto.getDesc()),
                        removeBlank(resultsDto.getComment()),
                        removeBlank(resultsDto.getEntname()),
                        removeBlank(resultsDto.getEntval()),
                        removeBlank(resultsDto.getEntowner()),
                        removeBlank(resultsDto.getStatus()),
                        removeBlank(resultsDto.getId()),
                        removeBlank(resultsDto.getCreatedDate()),
                        removeBlank(resultsDto.getEffectiveDate())});

    }

    public void responseToCSV2(List<String[]> dataLines) throws IOException {

        log.info("WRITING TO CSV FILE PATH 1 {}" + path1);

        try (CSVWriter writer = new CSVWriter(new FileWriter(path1))) {
            writer.writeAll(dataLines);
        }
    }

    public void responseToTSV2(List<String[]> dataLines) throws IOException {

        log.info("WRITING TO CSV FILE PATH 2 {}" + path2);

        try (CSVWriter writer = new CSVWriter(new FileWriter(path2),
                '\t',
                CSVWriter.NO_QUOTE_CHARACTER,
                CSVWriter.DEFAULT_ESCAPE_CHARACTER,
                CSVWriter.DEFAULT_LINE_END)) {
            writer.writeAll(dataLines);
        }
    }

    private static String removeBlank(String text) {
        if (Objects.equals(text, "") ||
                Objects.equals(text, "null") ||
                text == null ||
                text.isEmpty()) {
            return "-";
        }
        return text;
    }
}
