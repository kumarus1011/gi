package com.code.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResultsDto {

    private String owner;

    private String owndate;

    private String desc;

    private String comment;

    private String entname;

    private String entval;

    private String entowner;

    private String status;

    private String id;

    @JsonProperty("created_date")
    private String createdDate;

    @JsonProperty("efective_date")
    private String effectiveDate;

}
