package com.code.resources;

import com.code.service.UserService;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Path("/api/v1/users")
public class JerseyService {

    UserService userService = new UserService();

    @GET
    @Path(value = "/v3")
    public String getMsg() {
        return userService.saveOld();
    }
}
