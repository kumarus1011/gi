package com.code.task24.scheduler;

import com.code.task24.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

@Slf4j
@Configuration
@EnableScheduling
public class TestScheduler {

    @Value("${scheduler.enabled}")
    private boolean enabled;

    @Autowired
    private final UserService userService;

    public TestScheduler(UserService userService) {
        this.userService = userService;
    }

    @Scheduled(fixedDelayString = "${scheduler.triggeringIntervalMilliSeconds}",
            initialDelayString = "${scheduler.initialDelayIntervalMilliSeconds}")
    public void Task() {

        try {

            if (this.enabled) {

                log.info("STARTED SCHEDULER");

                userService.saveOld();

            } else {
                log.debug("SCHEDULER DISABLED");
            }

        } catch (Exception e) {
            log.error("ERROR WHILE EXECUTING SCHEDULER {}", e.getMessage());
        }

    }
}
