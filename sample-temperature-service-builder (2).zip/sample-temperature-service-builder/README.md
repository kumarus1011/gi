# Sample Temperature Liferay Service Builder

[![Antonio Musarra's Blog](https://img.shields.io/badge/maintainer-Antonio_Musarra's_Blog-purple.svg?colorB=6e60cc)](https://www.dontesta.it)
[![Twitter Follow](https://img.shields.io/twitter/follow/antonio_musarra.svg?style=social&label=%40antonio_musarra%20on%20Twitter&style=plastic)](https://twitter.com/antonio_musarra)

Sample project showing Liferay's Service Builder in action. This project is used 
by this other projects:

1. [Liferay 7: How to access OSGi services from the JSF portlet](https://github.com/amusarra/liferay-7-jsf-primefaces-portlet)
2. [Liferay JSF PrimeFaces OSGi/CDI portlet example](https://github.com/amusarra/liferay-73-jsf-primefaces-cdi-portlet)

I made this small project to respond to a reader of my blog and in particular 
on article [Liferay 7: How to access OSGi services from the JSF portlet](https://www.dontesta.it/en/2018/01/14/liferay-7-how-to-access-osgi-services-from-jsf-portlet).

Please check the Changelog to understand which version of the project is 
compatible with the specific version of Liferay.

## Quick Start

```bash
$ git clone https://github.com/amusarra/sample-temperature-service-builder.git
$ cd sample-temperature-service-builder.git
$ ./gradlew clean build
```
Console 1 - Build the API and Service of the Sample Temperature Service


```bash
.
├── sample-temperature-service-builder-api
│   ├── build
│   │   ├── libs
│   │   │   └── it.dontesta.labs.services.temperature.api-2.0.0.jar
├── sample-temperature-service-builder-service
│   ├── build
│   │   ├── libs
│   │   │   └── it.dontesta.labs.services.temperature.service-2.0.0.jar
```
Console 2 - View the artifact jar after build

After the build you can deploy the Service and API on the Liferay instance.
After the deployment of the service, some sample data entries will be created 
on the database; this in order to verify that everything is working correctly.

The class that loads the initial data into the database is [TemperatureServiceLifecycleListener](sample-temperature-service-builder-api/src/main/java/it/dontesta/labs/services/temperature/instance/lifecycle/TemperatureServiceLifecycleListener.java)

Below is an example of deployment and initialization with sample data.

```bash
2021-12-22 17:04:11.685 INFO  [com.liferay.portal.kernel.deploy.auto.AutoDeployScanner][AutoDeployDir:271] Processing it.dontesta.labs.services.temperature.api-2.0.0.jar
2021-12-22 17:04:20.518 INFO  [fileinstall-directory-watcher][BundleStartStopLogger:46] STARTED it.dontesta.labs.services.temperature.api_2.0.0 [1433]
2021-12-22 17:04:53.729 INFO  [com.liferay.portal.kernel.deploy.auto.AutoDeployScanner][AutoDeployDir:271] Processing it.dontesta.labs.services.temperature.service-2.0.0.jar
2021-12-22 17:05:00.967 INFO  [fileinstall-directory-watcher][BundleStartStopLogger:46] STARTED it.dontesta.labs.services.temperature.service_2.0.0 [1434]
2021-12-22 17:05:01.016 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:57] Creating the entries for Temperature...
2021-12-22 17:05:01.038 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:77] The entry for Temperature created with id 1
2021-12-22 17:05:01.043 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:77] The entry for Temperature created with id 2
2021-12-22 17:05:01.049 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:77] The entry for Temperature created with id 3
2021-12-22 17:05:01.055 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:77] The entry for Temperature created with id 4
2021-12-22 17:05:01.059 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:77] The entry for Temperature created with id 5
2021-12-22 17:05:01.061 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:77] The entry for Temperature created with id 6
2021-12-22 17:05:01.064 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:77] The entry for Temperature created with id 7
2021-12-22 17:05:01.065 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:77] The entry for Temperature created with id 8
2021-12-22 17:05:01.067 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:77] The entry for Temperature created with id 9
2021-12-22 17:05:01.069 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:77] The entry for Temperature created with id 10
2021-12-22 17:05:01.070 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:77] The entry for Temperature created with id 11
2021-12-22 17:05:01.072 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:77] The entry for Temperature created with id 12
2021-12-22 17:05:01.074 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:77] The entry for Temperature created with id 13
2021-12-22 17:05:01.075 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:77] The entry for Temperature created with id 14
2021-12-22 17:05:01.078 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:77] The entry for Temperature created with id 15
2021-12-22 17:05:01.080 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:77] The entry for Temperature created with id 16
2021-12-22 17:05:01.082 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:77] The entry for Temperature created with id 17
2021-12-22 17:05:01.084 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:77] The entry for Temperature created with id 18
2021-12-22 17:05:01.086 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:77] The entry for Temperature created with id 19
2021-12-22 17:05:01.087 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:77] The entry for Temperature created with id 20
2021-12-22 17:05:01.088 INFO  [fileinstall-directory-watcher][TemperatureServiceLifecycleListener:82] Creating the entries for Temperature...[END]
```

## Project License
The MIT License (MIT)

Copyright © 2021 Antonio Musarra's Blog - https://www.dontesta.it, antonio.musarra@gmail.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.