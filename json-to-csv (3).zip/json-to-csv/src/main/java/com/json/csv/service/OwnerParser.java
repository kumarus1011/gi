package com.json.csv.service;

import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.json.csv.response.OwnerResponse;

public class OwnerParser {

	private static final ObjectMapper XML_MAPPER = new XmlMapper();
	private static final ObjectMapper JSON_MAPPER = new ObjectMapper();

	public static String serialize(OwnerResponse ownerResponse, String format) throws IOException {
		return format.equalsIgnoreCase("JSON") ? serialize(ownerResponse, JSON_MAPPER) : serialize(ownerResponse, XML_MAPPER);
	}

	private static String serialize(OwnerResponse ownerResponse, ObjectMapper objectMapper) throws IOException {
		try {
			
			return objectMapper.writeValueAsString(ownerResponse);
			
		} catch (IOException e) {
			throw new IOException("Oh no!");
		}
	}
}
