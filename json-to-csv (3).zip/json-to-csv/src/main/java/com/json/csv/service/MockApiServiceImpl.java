package com.json.csv.service;

import java.io.FileWriter;
import java.io.IOException;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.json.csv.response.OwnerResponse;

@Service
public class MockApiServiceImpl implements MockApiService{
	
	@Autowired
	private Environment env;
	
	/* NOTE :::: You must change file location when you run this project in your own machine. */
	public static String XML_FILE_SAVE_LOCATION = "C://Users//SachithT//Desktop//";

	public static String XML_FILE_NAME = "data.xml";
	
	
	@Override
	public String getOwnerData() throws Exception {
		
		try {
			
			/* Load API Url from property file */
			String mockApiUrl = env.getProperty("mock.api.url");
			
			/* Initiate Rest Template Object */
			RestTemplate restTemplate = new RestTemplate();
			
			/* Initiate HTTP Response object */
			ResponseEntity<String> response = null;
			
			/* Invoke Mock API using Rest Template exchange method  */
			response = restTemplate.exchange(mockApiUrl, HttpMethod.GET, null, String.class);
			
			/* Check API is successfully responded or not using hasBody() method */
			if(!response.hasBody()) {
				return null;
			}
			
			/* Convert Response Body into Java object */
			OwnerResponse ownerResponse = jsonToJavaObject(response.getBody(), OwnerResponse.class);
			
			/* Java Object to JSON Object */
			JSONObject jsonObject = new JSONObject(ownerResponse);
			
			/* Get Result list array from json object */
			JSONArray jsonArray = jsonObject.getJSONArray("result");
			
			/* Convert json array into XML */
			String xml = "<?xml version=\"1.0\" encoding=\"ISO-8859-15\"?>\n<root>" + XML.toString(jsonArray, "result") + "</root>";
			
			String xmlFinal = convertJsonToXml(ownerResponse);
			
			if(xmlFinal == null) {
				return "Unknow error occured....";
			}
			
			String xmlFormatFinal = "<?xml version=\"1.0\" encoding=\"ISO-8859-15\"?>\n" + xmlFinal;

			/* Save XML file location */
			FileWriter file = new FileWriter(XML_FILE_SAVE_LOCATION+XML_FILE_NAME);
            file.write(xmlFormatFinal);
            
            file.flush();  
            file.close();  
			
			return "Your XML data is successfully written into data.xml file";
			
		} catch (HttpClientErrorException e) {
			
			System.out.println("Unknow error occured....");
			return "Unknow error occured....";
			
		} catch (Exception e) {
			
			System.out.println("Unknow error occured....");
			return "Unknow error occured....";
		}
	}
	
	
	/*
	 * This is a helper method for convert JSON to Java object 
	 * 
	 */
	public static synchronized <T extends Object> T jsonToJavaObject(String jsonString, Class<T> classType) {

		try {
			
			ObjectMapper mapper = new ObjectMapper();
			Object ob = classType.newInstance();
			return (T) (ob = mapper.readValue(jsonString, classType));
			
		} catch (JsonParseException e) {
			
			e.printStackTrace();
			return null;
		} catch (JsonMappingException e) {
			
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			
			e.printStackTrace();
			return null;
		} catch (InstantiationException e) {
			
			e.printStackTrace();
			return null;
		} catch (IllegalAccessException e) {
			
			e.printStackTrace();
			return null;
		}

	}
	
	/* Convert into XML */
	public String convertJsonToXml(OwnerResponse ownerResponse) throws IOException {
		return OwnerParser.serialize(ownerResponse, "XML");
	}

}
