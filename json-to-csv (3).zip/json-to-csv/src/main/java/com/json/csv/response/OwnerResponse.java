package com.json.csv.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

@JsonIgnoreProperties(ignoreUnknown = true)
@JacksonXmlRootElement(localName = "root")
public class OwnerResponse {

	@JsonProperty
	private String requestId;
	
	@JsonProperty
	private String anyKey;
	
	@JsonProperty
	private String run;
	
	@JsonProperty
	private String reco;
	
	@JsonProperty
	@JacksonXmlElementWrapper(localName = "results")
	@JacksonXmlProperty(localName = "result")
	private List<OwnerDataResponse> result;
	
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getAnyKey() {
		return anyKey;
	}
	public void setAnyKey(String anyKey) {
		this.anyKey = anyKey;
	}
	public String getRun() {
		return run;
	}
	public void setRun(String run) {
		this.run = run;
	}
	public String getReco() {
		return reco;
	}
	public void setReco(String reco) {
		this.reco = reco;
	}
	public List<OwnerDataResponse> getResult() {
		return result;
	}
	public void setResult(List<OwnerDataResponse> result) {
		this.result = result;
	}
}
