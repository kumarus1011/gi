package com.json.csv.service;

import com.json.csv.response.OwnerResponse;

public interface MockApiService {

	public String getOwnerData() throws Exception;
}
