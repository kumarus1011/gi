package com.json.csv;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.web.client.RestTemplate;

import com.json.csv.service.MockApiService;

@SpringBootApplication
public class JsonToCsvApplication {

	@Autowired
	public MockApiService mockApiService;
	
	public static void main(String[] args) throws Exception {
		SpringApplication.run(JsonToCsvApplication.class, args);
	}
	
	@Bean(name = "restTemplate")
	@Primary
	public RestTemplate restTemplate() {
	    return new RestTemplate();
	}
	
	@PostConstruct
	public void test() throws Exception {
		String result = mockApiService.getOwnerData();
		System.out.println(result);
	}
	

}
