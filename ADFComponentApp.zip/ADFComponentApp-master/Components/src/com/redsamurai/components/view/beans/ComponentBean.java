package com.redsamurai.components.view.beans;

import javax.faces.event.ActionEvent;

public interface ComponentBean {
    public void processSelection(ActionEvent actionEvent);
}
